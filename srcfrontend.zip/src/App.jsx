import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import Layout from './components/layout/Layout'
import Home from './pages/Home'
import ArticlePage from './pages/ArticlePage'
import CategoryPage from './pages/CategoryPage'
import SearchPage from './pages/SearchPage'
import About from './pages/About'
import Contact from './pages/Contact'
import NotFound from './pages/NotFound'

const categories = ['nigeria', 'africa', 'world', 'entertainment', 'tech', 'business', 'lifestyle', 'opinion']

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/article/:slug" element={<ArticlePage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          {categories.map(cat => (
            <Route key={cat} path={`/${cat}`} element={<CategoryPage />} />
          ))}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Layout>
      <Toaster
        position="top-right"
        toastOptions={{
          style: { background: '#111111', color: '#fff', border: '1px solid #ffffff' },
          success: { iconTheme: { primary: '#ffffff', secondary: '#111111' } },
        }}
      />
    </BrowserRouter>
  )
}
