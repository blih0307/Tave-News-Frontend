import axios from 'axios'

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL })

export const getArticles = (params = {}) => api.get('/articles', { params })
export const getArticle = (slug) => api.get(`/articles/${slug}`)
export const getRelated = (id) => api.get(`/articles/${id}/related`)
export const getCategories = () => api.get('/categories')
export const subscribe = (email) => api.post('/newsletter/subscribe', { email })

export const formatDate = (date) => new Date(date).toLocaleDateString('en-GB', {
  day: 'numeric', month: 'long', year: 'numeric'
})

export const timeAgo = (date) => {
  const seconds = Math.floor((new Date() - new Date(date)) / 1000)
  if (seconds < 60) return 'Just now'
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`
  return formatDate(date)
}

export const truncate = (str, n) => str?.length > n ? str.slice(0, n) + '...' : str
export const readTime = (content = '') => {
  const words = content.replace(/<[^>]*>/g, '').trim().split(/\s+/).filter(Boolean).length
  return Math.max(1, Math.round(words / 200))
}