import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { Helmet } from 'react-helmet-async'
import { getArticle, getRelated, timeAgo, readTime } from '../utils/api'
import AdBanner from '../components/ui/AdBanner'
import Newsletter from '../components/ui/Newsletter'
import { ArticleSkeleton } from '../components/ui/Skeleton'

const serif = { fontFamily: "'Playfair Display', Georgia, serif" }
const body = { fontFamily: "Georgia, 'Times New Roman', serif" }

function shareUrl(platform, title, url) {
  const encodedUrl = encodeURIComponent(url)
  const encodedTitle = encodeURIComponent(title)
  switch (platform) {
    case 'twitter': return `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`
    case 'facebook': return `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`
    case 'whatsapp': return `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`
    default: return null
  }
}

export default function ArticlePage() {
  const { slug } = useParams()
  const [article, setArticle] = useState(null)
  const [related, setRelated] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    window.scrollTo(0, 0)
    setLoading(true)
    setError(false)
    getArticle(slug)
      .then(res => { setArticle(res.data.data); return getRelated(res.data.data._id) })
      .then(res => setRelated(res.data.data || []))
      .catch(() => setError(true))
      .finally(() => setLoading(false))
  }, [slug])

  const handleShare = (platform) => {
    const url = window.location.href
    if (platform === 'copy') {
      navigator.clipboard.writeText(url)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      return
    }
    const link = shareUrl(platform, article?.title || '', url)
    if (link) window.open(link, '_blank', 'noopener,noreferrer')
  }

  if (loading) return (
    <div className="max-w-screen-xl mx-auto px-4 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-4 animate-pulse">
          <div className="h-10 bg-gray-200 rounded w-3/4" />
          <div className="aspect-video bg-gray-200 rounded" />
          {[...Array(5)].map((_, i) => <div key={i} className="h-4 bg-gray-200 rounded" />)}
        </div>
        <div className="space-y-6">{[...Array(3)].map((_, i) => <ArticleSkeleton key={i} />)}</div>
      </div>
    </div>
  )

  if (error || !article) return (
    <div className="max-w-2xl mx-auto px-4 py-16 text-center">
      <h1 className="text-2xl font-bold text-zinc-900 mb-4">Article not found</h1>
      <Link to="/" className="text-sm font-bold underline text-zinc-700">← Back to Home</Link>
    </div>
  )

  const minutes = Math.max(1, Math.ceil((article.content?.replace(/<[^>]+>/g, '').length || 500) / 1000))

  return (
    <>
      <Helmet>
        <title>{article.seo?.metaTitle || article.title} — Ten News</title>
        <meta name="description" content={article.seo?.metaDescription || article.excerpt} />
        {article.featuredImage?.url && <meta property="og:image" content={article.featuredImage.url} />}
      </Helmet>

      <div className="max-w-screen-xl mx-auto px-4 py-6">
        <div className="max-w-2xl mx-auto lg:max-w-none lg:grid lg:grid-cols-3 lg:gap-10">

          {/* ── MAIN ARTICLE ── */}
          <article className="lg:col-span-2">

            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-xs text-zinc-500 mb-4 flex-wrap">
              <Link to="/" className="hover:underline">Home</Link>
              <span>›</span>
              {article.category?.name && (
                <>
                  <Link to={`/${article.category.slug}`} className="hover:underline capitalize">
                    {article.category.name}
                  </Link>
                  <span>›</span>
                </>
              )}
              <span className="text-zinc-400 line-clamp-1">{article.title}</span>
            </div>

            {/* Category tag */}
            {article.category?.name && (
              <div className="mb-3">
                <Link
                  to={`/${article.category.slug}`}
                  className="inline-block bg-black text-white text-[11px] font-bold uppercase tracking-wider px-2 py-1 hover:bg-red-600 transition-colors"
                >
                  {article.category.name}
                </Link>
              </div>
            )}

            {/* Headline */}
            <h1 className="text-2xl sm:text-3xl font-black leading-tight text-zinc-900 mb-3" style={serif}>
              {article.title}
            </h1>

            {/* Excerpt */}
            {article.excerpt && (
              <p className="text-base text-zinc-600 leading-relaxed mb-4 border-l-4 border-black pl-4">
                {article.excerpt}
              </p>
            )}

            {/* Meta */}
            <div className="flex items-center gap-3 text-xs text-zinc-500 pb-4 border-b border-gray-300 mb-5 flex-wrap">
              {article.author?.name && (
                <span>By <span className="font-bold text-zinc-800">{article.author.name}</span></span>
              )}
              <span>·</span>
              <span>{timeAgo(article.publishedAt)}</span>
              <span>·</span>
              <span>{minutes} min read</span>
              {/* {typeof article.views === 'number' && (
                <>
                  <span>·</span>
                  <span>{article.views} views</span>
                </>
              )} */}
            </div>

            {/* Hero image */}
            {article.featuredImage?.url && (
              <div className="mb-6 overflow-hidden">
                <img
                  src={article.featuredImage.url}
                  alt={article.featuredImage.alt || article.title}
                  className="w-full h-[240px] sm:h-[380px] object-cover object-center"
                />
                <p className="text-[10px] text-zinc-400 mt-1 italic">
                  {article.featuredImage.alt || `Photo: Ten News / ${timeAgo(article.publishedAt)}`}
                </p>
              </div>
            )}

            

            {/* Body */}
            <div
              className="space-y-4 mt-6 text-[15px] text-zinc-800 leading-relaxed"
              style={body}
              dangerouslySetInnerHTML={{ __html: article.content }}
            />

            {article.embeddedVideo && (
              <div className="mt-8">
                <div className="border-t-4 border-black pt-3 mb-4">
                  <h3 className="font-black text-black uppercase tracking-wide text-sm">Watch</h3>
                </div>
                <div className="aspect-video overflow-hidden bg-black">
                  <iframe src={article.embeddedVideo} className="w-full h-full" allowFullScreen title="Video" />
                </div>
              </div>
            )}

            {/* Tags */}
            {article.tags?.length > 0 && (
              <div className="mt-8 flex flex-wrap gap-2">
                {article.tags.map(tag => (
                  <Link
                    key={tag}
                    to={`/search?q=${tag}`}
                    className="text-[10px] font-bold uppercase tracking-wide border border-zinc-300 px-2.5 py-1 text-zinc-600 hover:bg-zinc-100 transition-colors"
                  >
                    {tag}
                  </Link>
                ))}
              </div>
            )}

            <AdBanner />

            {/* Share row */}
            <div className="mt-8 pt-5 border-t border-gray-300 flex items-center gap-3 flex-wrap">
              <span className="text-xs font-bold text-zinc-600 uppercase tracking-wide">Share:</span>
              <button
                onClick={() => handleShare('twitter')}
                className="text-xs font-bold border border-zinc-300 px-3 py-1.5 hover:bg-zinc-900 hover:text-white hover:border-zinc-900 transition-colors text-zinc-700"
              >
                Twitter / X
              </button>
              <button
                onClick={() => handleShare('facebook')}
                className="text-xs font-bold border border-zinc-300 px-3 py-1.5 hover:bg-zinc-900 hover:text-white hover:border-zinc-900 transition-colors text-zinc-700"
              >
                Facebook
              </button>
              <button
                onClick={() => handleShare('whatsapp')}
                className="text-xs font-bold border border-zinc-300 px-3 py-1.5 hover:bg-zinc-900 hover:text-white hover:border-zinc-900 transition-colors text-zinc-700"
              >
                WhatsApp
              </button>
              <button
                onClick={() => handleShare('copy')}
                className="text-xs font-bold border border-zinc-300 px-3 py-1.5 hover:bg-zinc-900 hover:text-white hover:border-zinc-900 transition-colors text-zinc-700"
              >
                {copied ? 'Copied!' : 'Copy Link'}
              </button>
            </div>

            <div className="mt-10"><Newsletter /></div>
          </article>

          {/* ── SIDEBAR ── */}
          <aside className="hidden lg:block">
            <div className="sticky top-6 space-y-8">
              {/* More Stories */}
              <div>
                <div className="flex items-center gap-2 mb-4 border-b-[3px] border-zinc-900 pb-2">
                  <h2 className="text-sm font-black uppercase tracking-wide text-zinc-900">More Stories</h2>
                </div>
                <div className="divide-y divide-gray-300">
                  {related.slice(0, 6).map(r => (
                    <Link
                      key={r._id}
                      to={`/article/${r.slug}`}
                      className="flex items-start gap-3 py-3 group hover:bg-zinc-50 transition-colors -mx-2 px-2"
                    >
                      <div className="shrink-0 w-20 h-14 bg-gray-200 overflow-hidden">
                        {r.featuredImage?.url
                          ? <img src={r.featuredImage.url} alt={r.title} className="w-full h-full object-cover object-center" loading="lazy" />
                          : <div className="w-full h-full bg-gray-200" />
                        }
                      </div>
                      <div className="flex-1 min-w-0">
                        {r.category?.name && (
                          <span className="text-[9px] font-black uppercase tracking-wider text-zinc-500 block mb-0.5">{r.category.name}</span>
                        )}
                        <h4 className="text-xs font-bold leading-snug text-zinc-900 group-hover:underline line-clamp-3">
                          {r.title}
                        </h4>
                        <span className="text-[10px] text-zinc-400 mt-0.5 block">{timeAgo(r.publishedAt)}</span>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>

              {/* Trending */}
              {related.slice(6).length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-4 border-b-[3px] border-zinc-900 pb-2">
                    <h2 className="text-sm font-black uppercase tracking-wide text-zinc-900">Trending</h2>
                  </div>
                  <div className="space-y-3">
                    {related.slice(6).map((r, i) => (
                      <Link key={r._id} to={`/article/${r.slug}`} className="flex gap-3 group items-start">
                        <span className="text-3xl font-black text-zinc-200 leading-none shrink-0 mt-0.5 w-8 text-right">
                          {i + 1}
                        </span>
                        <div className="flex-1 min-w-0">
                          <h5 className="text-xs font-bold leading-snug text-zinc-900 group-hover:underline line-clamp-3">
                            {r.title}
                          </h5>
                          <span className="text-[10px] text-zinc-400 mt-0.5 block">{timeAgo(r.publishedAt)}</span>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </aside>
        </div>

        {/* ── RELATED STORIES (mobile) ── */}
        {related.length > 0 && (
          <div className="lg:hidden mt-8 border-t border-gray-300 pt-6">
            <div className="border-b-[3px] border-zinc-900 pb-2 mb-4">
              <h2 className="text-sm font-black uppercase tracking-wide text-zinc-900">More Stories</h2>
            </div>
            <div className="divide-y divide-gray-300">
              {related.slice(0, 5).map(r => (
                <Link
                  key={r._id}
                  to={`/article/${r.slug}`}
                  className="flex items-start gap-3 py-4 group hover:bg-zinc-50 transition-colors"
                >
                  <div className="flex-1 min-w-0">
                    {r.category?.name && (
                      <span className="text-[9px] font-black uppercase tracking-wider text-zinc-500 block mb-0.5">{r.category.name}</span>
                    )}
                    <h4 className="text-sm font-bold leading-snug text-zinc-900 group-hover:underline line-clamp-3">
                      {r.title}
                    </h4>
                    <span className="text-xs text-zinc-500 mt-1 block">{timeAgo(r.publishedAt)}</span>
                  </div>
                  <div className="w-20 h-14 bg-gray-200 shrink-0 overflow-hidden">
                    {r.featuredImage?.url
                      ? <img src={r.featuredImage.url} alt={r.title} className="w-full h-full object-cover object-center" loading="lazy" />
                      : <div className="w-full h-full bg-gray-200" />
                    }
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </>
  )
}