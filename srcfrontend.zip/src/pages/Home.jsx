import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Helmet } from 'react-helmet-async'
import { getArticles, getCategories, timeAgo, truncate, readTime } from '../utils/api'
import Container from '../components/layout/Container'
import AdBanner from '../components/ui/AdBanner'
import BreakingTicker from '../components/ui/BreakingTicker'
import Newsletter from '../components/ui/Newsletter'
import { ArticleSkeleton } from '../components/ui/Skeleton'

const f = { fontFamily: "'Libre Franklin', Arial, sans-serif" }
const serif = { fontFamily: "'Playfair Display', Georgia, serif" }

// ── Shared bits ────────────────────────────────────────────────────
function SectionTitle({ title, to, light = false, accent = false }) {
  return (
    <div className={`flex items-center justify-between mb-5 ${accent ? "border-l-4 border-red-600 pl-3" : `pb-1.5 border-b ${light ? "border-zinc-600" : "border-gray-300"}`}`}>
      <h2 className={`text-xs font-black uppercase tracking-widest ${light ? "text-white" : "text-black"}`} style={f}>
        {title}
      </h2>
      {to && (
        <Link to={to} className={`text-xs font-semibold transition-colors ${light ? "text-zinc-400 hover:text-white" : "text-zinc-400 hover:text-black"}`} style={f}>
          See all ›
        </Link>
      )}
    </div>
  )
}

function Meta({ time, tag, light = false }) {
  return (
    <p className="text-xs mt-1.5 flex items-center gap-1.5" style={f}>
      <span className="text-zinc-400">{time}</span>
      {tag && (
        <>
          <span className="opacity-30">·</span>
          <span className={`font-bold uppercase tracking-wide text-[10px] ${light ? "text-zinc-300" : "text-zinc-600"}`}>{tag}</span>
        </>
      )}
    </p>
  )
}

function ArticleImage({ article, light, className }) {
  return article?.featuredImage?.url
    ? <img src={article.featuredImage.url} alt={article.title} className={className} loading="lazy" />
    : <div className={`${className} ${light ? 'bg-zinc-800' : 'bg-gray-200'}`} />
}

function FeaturedCard({ article, large = false, light = false, overlay = false }) {
  if (!article) return null
  if (overlay) {
    return (
      <Link to={`/article/${article.slug}`} className="group relative block overflow-hidden">
        <ArticleImage
          article={article}
          light={light}
          className={`w-full object-cover object-center group-hover:scale-[1.03] transition-transform duration-500 ${large ? "h-56 sm:h-72" : "h-44"}`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className={`font-black leading-snug text-white group-hover:underline line-clamp-3 ${large ? "text-lg sm:text-xl" : "text-sm"}`} style={serif}>
            {article.title}
          </h3>
          <Meta time={timeAgo(article.publishedAt)} tag={article.category?.name} light />
        </div>
      </Link>
    )
  }

  return (
    <Link to={`/article/${article.slug}`} className="group block">
      <div className="overflow-hidden">
        <ArticleImage
          article={article}
          light={light}
          className={`w-full object-cover object-center group-hover:scale-[1.02] transition-transform duration-500 ${large ? "h-52 sm:h-64 lg:h-72" : "h-40 sm:h-44"}`}
        />
      </div>
      <div className="pt-2">
        <h3 className={`font-bold leading-snug group-hover:underline line-clamp-3 ${large ? "text-xl sm:text-2xl" : "text-sm"} ${light ? "text-white" : "text-gray-900"}`} style={serif}>
          {article.title}
        </h3>
        {article.excerpt && (
          <p className={`text-sm mt-1 line-clamp-2 ${light ? "text-zinc-400" : "text-gray-500"}`} style={f}>
            {article.excerpt}
          </p>
        )}
        <Meta time={timeAgo(article.publishedAt)} tag={article.category?.name} light={light} />
      </div>
    </Link>
  )
}

function StoryRow({ article, light = false }) {
  if (!article) return null
  return (
    <Link to={`/article/${article.slug}`} className={`flex items-start gap-3 py-4 border-b group last:border-0 ${light ? "border-zinc-600" : "border-gray-300"}`}>
      <ArticleImage article={article} light={light} className="w-28 h-20 object-cover object-center shrink-0" />
      <div className="flex-1 min-w-0">
        <h4 className={`text-sm font-bold leading-snug group-hover:underline line-clamp-3 mb-2 ${light ? "text-white" : "text-gray-900"}`} style={f}>
          {article.title}
        </h4>
        <p className={`text-xs ${light ? "text-zinc-400" : "text-gray-400"}`} style={f}>
          {timeAgo(article.publishedAt)}
          {article.category?.name && (
            <span className="ml-2 pl-2 border-l border-gray-300 font-semibold uppercase tracking-wide text-[10px]">
              {article.category.name}
            </span>
          )}
        </p>
      </div>
    </Link>
  )
}

function TextStoryRow({ article, index, light = false, numbered = false }) {
  if (!article) return null
  return (
    <Link to={`/article/${article.slug}`} className={`flex items-start gap-3 py-3 border-b group last:border-0 ${light ? "border-zinc-600" : "border-gray-300"}`}>
      {numbered && (
        <span className="text-2xl font-black leading-none mt-0.5 shrink-0 w-8 text-right" style={{ ...f, color: light ? "#555" : "#e0e0e0" }}>
          {String(index + 1).padStart(2, "0")}
        </span>
      )}
      <div className="flex-1 min-w-0">
        <h4 className={`text-sm font-bold leading-snug group-hover:underline line-clamp-3 ${light ? "text-white" : "text-gray-900"}`} style={f}>
          {article.title}
        </h4>
        {article.excerpt && (
          <p className={`text-xs mt-0.5 line-clamp-2 ${light ? "text-zinc-500" : "text-gray-500"}`} style={f}>
            {article.excerpt}
          </p>
        )}
        <Meta time={timeAgo(article.publishedAt)} tag={article.category?.name} light={light} />
      </div>
    </Link>
  )
}

// ── HERO ───────────────────────────────────────────────────────────
function HeroSection({ hero, side }) {
  const left = side.slice(0, 2)
  const right = side.slice(2, 7)

  return (
    <section>
      {/* Desktop */}
      <div className="hidden lg:flex lg:gap-0 border border-gray-300" style={{ height: "480px" }}>
        <div className="flex flex-col divide-y divide-gray-300 border-r w-[22%] shrink-0 overflow-hidden">
          {left.map(a => (
            <Link key={a._id} to={`/article/${a.slug}`} className="group p-3 hover:bg-gray-50 transition-colors flex-1 flex flex-col overflow-hidden">
              <ArticleImage article={a} className="w-full h-20 object-cover object-center mb-2 shrink-0" />
              <h4 className="text-xs font-bold leading-snug text-gray-900 group-hover:underline line-clamp-2 mb-1" style={f}>
                {a.title}
              </h4>
              {a.excerpt && (
                <p className="text-xs text-gray-500 leading-relaxed line-clamp-3 flex-1" style={f}>
                  {a.excerpt}
                </p>
              )}
              <Meta time={timeAgo(a.publishedAt)} tag={a.category?.name} />
            </Link>
          ))}
        </div>

        <div className="border-r border-gray-300 flex-1 relative overflow-hidden">
          {hero && (
            <Link to={`/article/${hero.slug}`} className="group block absolute inset-0">
              <ArticleImage article={hero} className="w-full h-full object-cover object-center" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/30 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <h2 className="text-2xl xl:text-3xl font-black leading-tight text-white group-hover:underline" style={f}>
                  {hero.title}
                </h2>
                {hero.excerpt && (
                  <p className="text-sm text-zinc-200 mt-2 leading-relaxed" style={f}>
                    {hero.excerpt}
                  </p>
                )}
                <Meta time={timeAgo(hero.publishedAt)} tag={hero.category?.name} light />
              </div>
            </Link>
          )}
        </div>

        <div className="flex flex-col divide-y divide-gray-300 w-[22%] shrink-0 overflow-hidden">
          {right.map(a => (
            <Link key={a._id} to={`/article/${a.slug}`} className="group p-3 hover:bg-gray-50 transition-colors flex-1 flex flex-col overflow-hidden">
              <h4 className="text-xs font-bold leading-snug text-gray-900 group-hover:underline line-clamp-4 flex-1" style={f}>
                {a.title}
              </h4>
              {a.excerpt && <p className="text-xs text-gray-500 mt-1 line-clamp-2" style={f}>{a.excerpt}</p>}
              <Meta time={timeAgo(a.publishedAt)} tag={a.category?.name} />
            </Link>
          ))}
        </div>
      </div>

      {/* Mobile */}
      {hero && (
        <div className="lg:hidden -mx-4 sm:-mx-6">
          <Link to={`/article/${hero.slug}`} className="group block relative">
            <ArticleImage article={hero} className="w-full h-[420px] sm:h-[500px] object-cover object-center" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 px-4 pb-6">
              <span className="inline-block text-[10px] font-black uppercase tracking-widest bg-red-600 text-white px-2 py-0.5 mb-2">{hero.category?.name}</span>
              <h2 className="text-2xl font-black leading-snug text-white group-hover:underline" style={serif}>{hero.title}</h2>
              {hero.excerpt && (
                <p className="text-sm text-zinc-300 mt-2 leading-relaxed line-clamp-2" style={f}>{hero.excerpt}</p>
              )}
              <Meta time={timeAgo(hero.publishedAt)} tag={hero.category?.name} light />
            </div>
          </Link>
          <div className="px-4 sm:px-6 divide-y divide-gray-300">
            {side.slice(0, 4).map(a => (
              <StoryRow key={a._id} article={a} />
            ))}
          </div>
        </div>
      )}
    </section>
  )
}

// ── LATEST STORIES — red accent, 4 cards ──────────────────────────
function LatestSection({ stories }) {
  const top4 = stories.slice(0, 4)
  if (!top4.length) return null

  return (
    <section>
      <SectionTitle title="Latest Stories" to="/latest" accent />
      <div className="hidden lg:grid lg:grid-cols-4 lg:gap-4">
        {top4.map(a => <FeaturedCard key={a._id} article={a} overlay />)}
      </div>
      <div className="lg:hidden divide-y divide-gray-300">
        {top4.map(a => <StoryRow key={a._id} article={a} />)}
      </div>
    </section>
  )
}

// ── MORE NEWS — dark full-width block ─────────────────────────────
function MoreNewsSection({ articles = [], title = "More News" }) {
  if (!articles.length) return null
  return (
    <section style={{ backgroundColor: "#0a0a0a" }} className="-mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8 py-10">
      <div className="max-w-screen-xl mx-auto">
        <SectionTitle title={title} to="/latest" light />
        <div className="hidden lg:grid lg:grid-cols-4 lg:gap-4">
          {articles.slice(0, 4).map(a => <FeaturedCard key={a._id} article={a} light overlay />)}
        </div>
        <div className="lg:hidden divide-y divide-zinc-700">
          {articles.slice(0, 4).map((a, i) => (
            <TextStoryRow key={a._id} article={a} index={i} light />
          ))}
        </div>
      </div>
    </section>
  )
}

// ── CATEGORY SECTION — rotating 4 layouts ─────────────────────────
function CategorySection({ section, layoutIndex }) {
  const articles = section.articles || []
  const [featured, second, third] = articles
  if (!featured) return null
  const to = `/${section.category?.slug}`
  const name = section.category?.name

  // Layout 0: big left image (overlay) + right numbered text list
  if (layoutIndex % 4 === 0) {
    return (
      <section>
        <SectionTitle title={name} to={to} />
        <div className="hidden lg:grid lg:grid-cols-[2fr_1fr] lg:gap-6">
          <FeaturedCard article={featured} large overlay />
          <div className="flex flex-col divide-y divide-gray-300">
            {[second, third].filter(Boolean).map((a, i) => (
              <TextStoryRow key={a._id} article={a} index={i + 1} numbered />
            ))}
          </div>
        </div>
        <div className="lg:hidden">
          <FeaturedCard article={featured} overlay />
          <div className="mt-2 divide-y divide-gray-300">
            {articles.slice(1, 4).map(a => <StoryRow key={a._id} article={a} />)}
          </div>
        </div>
      </section>
    )
  }

  // Layout 1: 3-col equal grid, overlay cards
  if (layoutIndex % 4 === 1) {
    return (
      <section>
        <SectionTitle title={name} to={to} />
        <div className="hidden lg:grid lg:grid-cols-3 lg:gap-4">
          {[featured, second, third].filter(Boolean).map(a => (
            <FeaturedCard key={a._id} article={a} overlay />
          ))}
        </div>
        <div className="lg:hidden">
          <FeaturedCard article={featured} overlay />
          <div className="mt-2 divide-y divide-gray-300">
            {articles.slice(1, 4).map(a => <StoryRow key={a._id} article={a} />)}
          </div>
        </div>
      </section>
    )
  }

  // Layout 2: right-heavy — numbered list left, big image right, red accent title
  if (layoutIndex % 4 === 2) {
    return (
      <section>
        <SectionTitle title={name} to={to} accent />
        <div className="hidden lg:grid lg:grid-cols-[1fr_2fr] lg:gap-6">
          <div className="flex flex-col divide-y divide-gray-300">
            {[second, third].filter(Boolean).map((a, i) => (
              <TextStoryRow key={a._id} article={a} index={i + 1} numbered />
            ))}
          </div>
          <FeaturedCard article={featured} large overlay />
        </div>
        <div className="lg:hidden">
          <FeaturedCard article={featured} overlay />
          <div className="mt-2 divide-y divide-gray-300">
            {articles.slice(1, 4).map(a => <StoryRow key={a._id} article={a} />)}
          </div>
        </div>
      </section>
    )
  }

  // Layout 3: dark full-width — 3 cards
  return (
    <section style={{ backgroundColor: "#111" }} className="-mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8 py-10">
      <div className="max-w-screen-xl mx-auto">
        <SectionTitle title={name} to={to} light />
        <div className="hidden lg:grid lg:grid-cols-3 lg:gap-4">
          {[featured, second, third].filter(Boolean).map(a => (
            <FeaturedCard key={a._id} article={a} light overlay />
          ))}
        </div>
        <div className="lg:hidden divide-y divide-zinc-600">
          {articles.slice(0, 4).map((a, i) => (
            <TextStoryRow key={a._id} article={a} index={i} light />
          ))}
        </div>
      </div>
    </section>
  )
}

// ── HOME PAGE ──────────────────────────────────────────────────────
export default function Home() {
  const [hero, setHero] = useState(null)
  const [side, setSide] = useState([])
  const [moreNews, setMoreNews] = useState([])
  const [categorySections, setCategorySections] = useState([])
  const [latestGrid, setLatestGrid] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
  Promise.all([
  getArticles({ homePosition: 'center', limit: 1 }),
  getArticles({ homePosition: 'left', limit: 2 }),
  getArticles({ homePosition: 'right', limit: 5 }),
  getArticles({ limit: 60 }),
  getCategories(),
]).then(([centerRes, leftRes, rightRes, poolRes, catRes]) => {
  const heroArticle = centerRes.data.data[0] || null
  const leftArticles = leftRes.data.data || []
  const rightArticles = rightRes.data.data || []
  const sideArticles = [...leftArticles, ...rightArticles]
  const generalPool = poolRes.data.data || []
  const categories = (catRes.data.data || []).filter(c => !c.parent).slice(0, 4)

  const used = new Set([heroArticle?._id, ...sideArticles.map(a => a._id)].filter(Boolean))
  const claim = (list, n) => {
    const picked = list.filter(a => !used.has(a._id)).slice(0, n)
    picked.forEach(a => used.add(a._id))
    return picked
  }

  const moreNewsArticles = claim(generalPool, 4)
  const sections = categories.map(cat => {
    const pool = generalPool.filter(a => a.category?._id === cat._id)
    let articles = claim(pool, 5)
    if (articles.length === 0 && pool.length > 0) articles = pool.slice(0, 5)
    return { category: cat, articles }
  }).filter(s => s.articles.length > 0)

  const remaining = generalPool.filter(a => !used.has(a._id))

  setHero(heroArticle)
  setSide(sideArticles)
  setMoreNews(moreNewsArticles)
  setCategorySections(sections)
  setLatestGrid((remaining.length > 0 ? remaining : generalPool).slice(0, 6))
}).catch(console.error).finally(() => setLoading(false))
    .finally(() => setLoading(false))
  }, [])

  return (
    <>
      <Helmet>
        <title>Ten News — Nigeria, Africa & World News</title>
        <meta name="description" content="Breaking news, in-depth analysis and stories that matter from Nigeria, Africa and the world." />
      </Helmet>

      <BreakingTicker />

      <Container className="py-6">
        <AdBanner size="leaderboard" />

        {loading && (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            {[...Array(3)].map((_, i) => <ArticleSkeleton key={i} />)}
          </div>
        )}

        {!loading && (
          <div className="mt-8 space-y-12">
            <HeroSection hero={hero} side={side} />

            <LatestSection stories={moreNews} />

            <MoreNewsSection articles={latestGrid} />

            {categorySections.map((section, i) => (
              <div key={section.category._id}>
                <CategorySection section={section} layoutIndex={i} />

                {/* After every 3rd category section: ad + another dark More News block */}
                {(i + 1) % 3 === 0 && (
                  <>
                    <div>
                      <AdBanner />
                    </div>
                    <MoreNewsSection
                      articles={[
                        ...latestGrid.slice(2),
                        ...latestGrid.slice(0, 2),
                      ]}
                    />
                  </>
                )}
              </div>
            ))}

            <div>
              <AdBanner />
            </div>

            <Newsletter />
          </div>
        )}
      </Container>
    </>
  )
}