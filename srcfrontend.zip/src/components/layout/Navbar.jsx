import { useState, useEffect } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'

const topNav = [
  { to: '/', label: 'Home' },
  { to: '/nigeria', label: 'Nigeria' },
  { to: '/africa', label: 'Africa' },
  { to: '/world', label: 'World' },
  { to: '/entertainment', label: 'Entertainment' },
  { to: '/tech', label: 'Tech' },
  { to: '/business', label: 'Business' },
  { to: '/lifestyle', label: 'Lifestyle' },
  { to: '/opinion', label: 'Opinion' },
]

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [search, setSearch] = useState('')
  const [searchOpen, setSearchOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const handleSearch = (e) => {
    e.preventDefault()
    if (search.trim()) { navigate(`/search?q=${search}`); setSearch(''); setSearchOpen(false) }
  }

  return (
    <header className={`sticky top-0 z-50 transition-shadow ${scrolled ? 'shadow-lg' : ''}`}>
      {/* Top bar */}
      <div className="bg-black text-gray-500 text-xs py-1.5">
        <div className="max-w-[1600px] mx-auto px-6 flex justify-between items-center">
          <span className="hidden sm:block">{new Date().toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
          <div className="flex gap-4">
            {['Twitter', 'Facebook', 'Instagram', 'YouTube'].map(s => (
              <a key={s} href="#" className="hover:text-white transition-colors">{s}</a>
            ))}
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="bg-white border-b-4 border-black">
        <div className="max-w-[1600px] mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex-shrink-0">
            <div className="font-black text-3xl tracking-tight text-black">
              TEN <span className="bg-black text-white px-2">NEWS</span>
            </div>
            <div className="text-gray-400 text-xs tracking-widest uppercase mt-0.5">Nigeria · Africa · World</div>
          </Link>

          <Link to="/newsletter" className="hidden md:block bg-black text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-gray-800 transition-colors">Subscribe</Link>

          <div className="md:hidden flex items-center gap-1">
            <button onClick={() => setSearchOpen(o => !o)} className="text-black p-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </button>
            <button className="text-black text-xl p-2" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? '✕' : '☰'}
            </button>
          </div>
        </div>

        {/* Bottom nav */}
        <div className="hidden md:block border-t border-gray-200">
          <div className="max-w-[1600px] mx-auto px-6 flex items-center justify-between gap-4">
            <div className="w-9 flex-shrink-0" />
            <nav className="flex justify-center overflow-x-auto flex-1">
              {topNav.map(item => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === '/'}
                  className={({ isActive }) =>
                    `px-4 py-3 text-sm font-semibold whitespace-nowrap border-b-2 transition-all ${
                      isActive ? 'text-black border-black' : 'text-gray-500 border-transparent hover:text-black hover:border-gray-400'
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
            </nav>
            <button onClick={() => setSearchOpen(o => !o)} className="w-9 flex-shrink-0 flex justify-end text-gray-400 hover:text-black transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </button>
          </div>
        </div>

        {/* Search bar — shared for mobile + desktop */}
        {searchOpen && (
          <div className="border-t border-gray-200 bg-gray-50">
            <div className="max-w-[1600px] mx-auto px-6 py-3">
              <form onSubmit={handleSearch} className="flex items-center gap-2 md:max-w-md md:ml-auto">
                <input
                  autoFocus
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Search news..."
                  className="flex-1 bg-white text-black px-4 py-2 rounded-lg text-sm outline-none border border-gray-300 focus:border-black"
                />
                <button type="button" onClick={() => setSearchOpen(false)} className="text-gray-400 hover:text-black text-xl px-2">✕</button>
              </form>
            </div>
          </div>
        )}
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200 shadow-lg">
          <div className="px-6 py-3 space-y-1">
            {topNav.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/'}
                onClick={() => setMenuOpen(false)}
                className={({ isActive }) =>
                  `block px-3 py-2.5 rounded-lg text-sm font-medium ${isActive ? 'bg-black text-white' : 'text-gray-700 hover:bg-gray-100'}`
                }
              >
                {item.label}
              </NavLink>
            ))}
            <Link to="/newsletter" onClick={() => setMenuOpen(false)} className="block bg-black text-white text-center px-3 py-2.5 rounded-lg text-sm font-bold mt-2">Subscribe</Link>
          </div>
        </div>
      )}
    </header>
  )
}