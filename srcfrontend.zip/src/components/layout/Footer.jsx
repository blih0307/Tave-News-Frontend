import { Link } from 'react-router-dom'

const sections = [
  { title: 'News', links: [{ to: '/nigeria', label: 'Nigeria' }, { to: '/africa', label: 'Africa' }, { to: '/world', label: 'World' }, { to: '/entertainment', label: 'Entertainment' }] },
  { title: 'More', links: [{ to: '/tech', label: 'Tech' }, { to: '/business', label: 'Business' }, { to: '/lifestyle', label: 'Lifestyle' }, { to: '/opinion', label: 'Opinion' }] },
  { title: 'Company', links: [{ to: '/about', label: 'About Us' }, { to: '/contact', label: 'Contact' }, { to: '/advertise', label: 'Advertise' }, { to: '/careers', label: 'Careers' }] },
]

export default function Footer() {
  return (
    <footer className="bg-black border-t-4 border-black mt-16">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">
          <div className="col-span-2 md:col-span-1">
            <div className="font-black text-xl mb-3 text-white">TEN <span className="bg-white text-black px-1">NEWS</span></div>
            <p className="text-gray-500 text-sm leading-relaxed mb-4">Breaking news, in-depth analysis and stories that matter — from Nigeria, across Africa and around the world.</p>
            <div className="flex gap-3">
              {['T', 'F', 'I', 'Y'].map((s, i) => (
                <a key={i} href="#" className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center text-gray-400 hover:bg-white hover:text-black transition-all text-xs font-bold">{s}</a>
              ))}
            </div>
          </div>
          {sections.map(section => (
            <div key={section.title}>
              <h4 className="text-white text-xs font-bold uppercase tracking-widest mb-4">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map(link => (
                  <li key={link.to}><Link to={link.to} className="text-gray-500 text-sm hover:text-white transition-colors">{link.label}</Link></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-gray-800 pt-6 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p className="text-gray-600 text-xs">© {new Date().getFullYear()} Ten News. All rights reserved.</p>
          <div className="flex gap-4">
            {['Privacy Policy', 'Terms of Use', 'Cookie Settings'].map(l => (
              <a key={l} href="#" className="text-gray-600 text-xs hover:text-gray-400 transition-colors">{l}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
