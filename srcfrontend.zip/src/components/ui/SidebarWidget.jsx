import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { getArticles, timeAgo } from '../../utils/api'
import { HorizontalSkeleton } from './Skeleton'

export default function SidebarWidget({ title = 'Most Read', limit = 5 }) {
  const [articles, setArticles] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getArticles({ limit })
      .then(res => setArticles(res.data.data || []))
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  return (
    <div>
      <div className="border-t-4 border-black pt-3 mb-4">
        <h3 className="font-black text-black uppercase tracking-wide text-sm">{title}</h3>
      </div>
      <div className="space-y-4">
        {loading
          ? [...Array(limit)].map((_, i) => <HorizontalSkeleton key={i} />)
          : articles.map((article, i) => (
            <Link key={article._id} to={`/article/${article.slug}`} className="group flex gap-3 hover:bg-gray-50 rounded-lg p-2 -mx-2 transition-colors">
              <span className="text-black font-black text-2xl leading-none w-6 flex-shrink-0 opacity-20">{i + 1}</span>
              <div>
                <span className="text-black text-xs font-bold uppercase border-b border-black pb-0.5">{article.category?.name}</span>
                <h4 className="text-gray-900 text-sm font-semibold leading-snug line-clamp-2 group-hover:underline mt-1">{article.title}</h4>
                <span className="text-gray-400 text-xs">{timeAgo(article.publishedAt)}</span>
              </div>
            </Link>
          ))
        }
      </div>
    </div>
  )
}
