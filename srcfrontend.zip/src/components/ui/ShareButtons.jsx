export default function ShareButtons({ title, url }) {
  const shareUrl = url || window.location.href
  const encoded = encodeURIComponent(shareUrl)
  const encodedTitle = encodeURIComponent(title || document.title)

  const buttons = [
    { label: 'Twitter', color: 'bg-black', href: `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encoded}` },
    { label: 'Facebook', color: 'bg-black', href: `https://www.facebook.com/sharer/sharer.php?u=${encoded}` },
    { label: 'WhatsApp', color: 'bg-black', href: `https://wa.me/?text=${encodedTitle}%20${encoded}` },
  ]

  const handleCopy = () => { navigator.clipboard.writeText(shareUrl); alert('Link copied!') }

  return (
    <div className="flex flex-wrap gap-2">
      {buttons.map(btn => (
        <a key={btn.label} href={btn.href} target="_blank" rel="noopener noreferrer"
          className="bg-black text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors">
          {btn.label}
        </a>
      ))}
      <button onClick={handleCopy} className="bg-gray-100 text-gray-700 text-xs font-semibold px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors">
        Copy Link
      </button>
    </div>
  )
}
