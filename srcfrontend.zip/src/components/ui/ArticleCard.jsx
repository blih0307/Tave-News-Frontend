import { Link } from 'react-router-dom'
import { timeAgo } from '../../utils/api'

export default function ArticleCard({ article, variant = 'default' }) {
  if (!article) return null

  if (variant === 'featured') return (
    <Link to={`/article/${article.slug}`} className="group block relative overflow-hidden rounded-xl bg-black">
      <div className="aspect-video bg-gray-200 overflow-hidden">
        {article.featuredImage?.url
          ? <img src={article.featuredImage.url} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80" />
          : <div className="w-full h-full bg-gray-300 flex items-center justify-center text-gray-500 text-sm">No Image</div>
        }
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-5">
        {article.isBreaking && <span className="bg-white text-black text-xs font-black px-2 py-0.5 rounded mb-2 inline-block mr-1">BREAKING</span>}
        <span className="bg-black text-white text-xs font-bold px-2 py-0.5 rounded mb-2 inline-block border border-white/30">{article.category?.name}</span>
        <h2 className="text-white font-black text-xl leading-tight group-hover:text-gray-200 transition-colors line-clamp-2 mt-1">{article.title}</h2>
        <p className="text-gray-400 text-sm mt-1">{timeAgo(article.publishedAt)}</p>
      </div>
    </Link>
  )

  if (variant === 'horizontal') return (
    <Link to={`/article/${article.slug}`} className="group flex gap-3 hover:bg-gray-50 rounded-lg p-2 -mx-2 transition-colors">
      <div className="w-20 h-16 flex-shrink-0 rounded-lg overflow-hidden bg-gray-200">
        {article.featuredImage?.url
          ? <img src={article.featuredImage.url} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
          : <div className="w-full h-full bg-gray-200" />
        }
      </div>
      <div className="flex-1 min-w-0">
        <span className="text-black text-xs font-bold uppercase border-b border-black pb-0.5">{article.category?.name}</span>
        <h3 className="text-gray-900 text-sm font-semibold leading-tight line-clamp-2 group-hover:underline mt-1">{article.title}</h3>
        <p className="text-gray-400 text-xs mt-1">{timeAgo(article.publishedAt)}</p>
      </div>
    </Link>
  )

  return (
    <Link to={`/article/${article.slug}`} className="group block">
      <div className="aspect-video rounded-xl overflow-hidden bg-gray-100 mb-3">
        {article.featuredImage?.url
          ? <img src={article.featuredImage.url} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
          : <div className="w-full h-full bg-gray-200 flex items-center justify-center text-gray-400 text-xs">No Image</div>
        }
      </div>
      <div className="space-y-1.5">
        <div className="flex items-center gap-2">
          <span className="text-black text-xs font-bold uppercase border-b-2 border-black pb-0.5">{article.category?.name}</span>
          {article.isBreaking && <span className="bg-black text-white text-xs font-bold px-2 py-0.5 rounded">BREAKING</span>}
        </div>
        <h3 className="text-gray-900 font-bold leading-snug line-clamp-2 group-hover:underline font-serif">{article.title}</h3>
        <p className="text-gray-500 text-sm line-clamp-2">{article.excerpt}</p>
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <span>{article.author?.name}</span>
          <span>·</span>
          <span>{timeAgo(article.publishedAt)}</span>
        </div>
      </div>
    </Link>
  )
}
